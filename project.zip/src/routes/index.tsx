import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw, Moon, Sun, Flame } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

const FOCUS_SECONDS = 25 * 60;

function todayKey() {
  const d = new Date();
  return `pomo-${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function useHydrated() {
  const [h, setH] = useState(false);
  useEffect(() => setH(true), []);
  return h;
}

function playBell() {
  try {
    const Ctx =
      (window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext })
        .AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [880, 660, 990].forEach((freq, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.value = freq;
      const start = now + i * 0.18;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(0.35, start + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, start + 0.6);
      o.connect(g).connect(ctx.destination);
      o.start(start);
      o.stop(start + 0.65);
    });
    setTimeout(() => ctx.close(), 2000);
  } catch {
    /* ignore */
  }
}

function Index() {
  const hydrated = useHydrated();
  const [secondsLeft, setSecondsLeft] = useState(FOCUS_SECONDS);
  const [running, setRunning] = useState(false);
  const [dark, setDark] = useState(false);
  const [sessions, setSessions] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load persisted state on mount
  useEffect(() => {
    const storedTheme = localStorage.getItem("pomo-theme");
    const prefersDark =
      storedTheme === "dark" ||
      (!storedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches);
    setDark(prefersDark);
    const stored = Number(localStorage.getItem(todayKey()) ?? "0");
    setSessions(Number.isFinite(stored) ? stored : 0);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("pomo-theme", dark ? "dark" : "light");
  }, [dark, hydrated]);

  const complete = useCallback(() => {
    playBell();
    setSessions((s) => {
      const next = s + 1;
      localStorage.setItem(todayKey(), String(next));
      return next;
    });
    setRunning(false);
    setSecondsLeft(FOCUS_SECONDS);
  }, []);

  useEffect(() => {
    if (!running) return;
    intervalRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          queueMicrotask(complete);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running, complete]);

  useEffect(() => {
    if (!hydrated) return;
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    document.title = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")} — Focus`;
  }, [secondsLeft, hydrated]);

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const progress = 1 - secondsLeft / FOCUS_SECONDS;
  const R = 140;
  const C = 2 * Math.PI * R;

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(600px 600px at 15% 10%, color-mix(in oklab, var(--color-primary) 22%, transparent), transparent 60%), radial-gradient(700px 700px at 90% 90%, color-mix(in oklab, var(--color-accent) 25%, transparent), transparent 60%)",
        }}
      />

      <div className="relative mx-auto flex min-h-screen max-w-3xl flex-col px-6 py-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm">
              <Flame className="h-5 w-5" />
            </div>
            <span className="text-lg font-semibold tracking-tight">focus.</span>
          </div>
          <button
            onClick={() => setDark((d) => !d)}
            aria-label="Toggle theme"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-card/60 backdrop-blur transition hover:bg-accent hover:text-accent-foreground"
          >
            {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </header>

        <section className="flex flex-1 flex-col items-center justify-center gap-10 py-12">
          <div className="text-center">
            <p className="text-sm uppercase tracking-[0.3em] text-muted-foreground">
              {running ? "Focusing" : "Ready when you are"}
            </p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight">
              25-minute deep work
            </h1>
          </div>

          <div className="relative">
            <svg width="320" height="320" viewBox="0 0 320 320" className="-rotate-90">
              <circle
                cx="160"
                cy="160"
                r={R}
                fill="none"
                stroke="var(--color-border)"
                strokeWidth="12"
              />
              <circle
                cx="160"
                cy="160"
                r={R}
                fill="none"
                stroke="var(--color-primary)"
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={C}
                strokeDashoffset={C * (1 - progress)}
                style={{ transition: "stroke-dashoffset 900ms linear" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="font-mono text-7xl font-semibold tabular-nums tracking-tight">
                {String(mins).padStart(2, "0")}
                <span className="opacity-40">:</span>
                {String(secs).padStart(2, "0")}
              </div>
              <div className="mt-2 text-xs uppercase tracking-[0.3em] text-muted-foreground">
                {running ? "in session" : "paused"}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setRunning((r) => !r)}
              className="inline-flex h-14 items-center gap-2 rounded-full bg-primary px-8 text-base font-medium text-primary-foreground shadow-lg shadow-primary/20 transition hover:brightness-110 active:scale-[0.98]"
            >
              {running ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              {running ? "Pause" : "Start"}
            </button>
            <button
              onClick={() => {
                setRunning(false);
                setSecondsLeft(FOCUS_SECONDS);
              }}
              className="inline-flex h-14 items-center gap-2 rounded-full border border-border bg-card/60 px-6 text-base font-medium backdrop-blur transition hover:bg-accent hover:text-accent-foreground"
            >
              <RotateCcw className="h-5 w-5" />
              Reset
            </button>
          </div>
        </section>

        <footer className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
                Today
              </p>
              <p className="mt-1 text-2xl font-semibold tabular-nums">
                {sessions}{" "}
                <span className="text-base font-normal text-muted-foreground">
                  {sessions === 1 ? "session" : "sessions"} completed
                </span>
              </p>
            </div>
            <div className="flex gap-1.5">
              {Array.from({ length: Math.min(8, Math.max(sessions, 1)) }).map((_, i) => (
                <div
                  key={i}
                  className={`h-8 w-2 rounded-full ${
                    i < sessions ? "bg-primary" : "bg-border"
                  }`}
                />
              ))}
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}
